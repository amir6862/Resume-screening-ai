"""
streamlit_app.py
----------------
Main Streamlit UI for the Resume Screening AI system.

Run with:
    streamlit run streamlit_app.py

Features:
  - Upload single or multiple PDF/TXT resumes
  - Paste job description
  - View match score, skill gap, and improvement tips
  - Multi-candidate ranking with visual leaderboard
  - Interactive charts (plotly)
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import sys
import os

# ── Page configuration (must be first Streamlit call) ────────────────────────
st.set_page_config(
    page_title="Resume Screening AI",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .score-card {
        padding: 1.5rem;
        border-radius: 12px;
        text-align: center;
        border: 1px solid rgba(0,0,0,0.1);
        margin: 0.5rem 0;
    }
    .score-number {
        font-size: 3rem;
        font-weight: 800;
        line-height: 1;
    }
    .score-label {
        font-size: 1rem;
        opacity: 0.8;
        margin-top: 0.5rem;
    }
    .skill-tag {
        display: inline-block;
        padding: 0.2rem 0.7rem;
        border-radius: 20px;
        font-size: 0.8rem;
        margin: 0.2rem;
        font-weight: 500;
    }
    .skill-matched { background: #d4edda; color: #155724; }
    .skill-missing { background: #f8d7da; color: #721c24; }
    .skill-extra   { background: #d1ecf1; color: #0c5460; }
    .suggestion-high   { border-left: 4px solid #e74c3c; padding-left: 1rem; }
    .suggestion-medium { border-left: 4px solid #f39c12; padding-left: 1rem; }
    .suggestion-low    { border-left: 4px solid #3498db; padding-left: 1rem; }
    .rank-card {
        padding: 1rem 1.5rem;
        border-radius: 10px;
        margin: 0.5rem 0;
        border: 1px solid rgba(0,0,0,0.08);
    }
</style>
""", unsafe_allow_html=True)


# ── Load pipeline (cached so it only loads once) ──────────────────────────────
@st.cache_resource(show_spinner="Loading AI models (first run may take a minute)...")
def load_pipeline():
    from app.pipeline import ScreeningPipeline
    return ScreeningPipeline(embedding_model="fast")


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/color/96/resume.png", width=80)
    st.title("Resume Screening AI")
    st.markdown("**AI-powered candidate evaluation**")
    st.divider()

    mode = st.radio(
        "Mode",
        ["Single Resume Analysis", "Multi-Candidate Ranking"],
        help="Analyze one resume in depth, or rank multiple candidates."
    )

    st.divider()
    st.markdown("""
    **How it works:**
    1. 📄 Upload resume(s)
    2. 📋 Paste job description
    3. 🤖 AI analyzes match
    4. 📊 View results
    """)

    st.divider()
    st.caption("Powered by Sentence-BERT + spaCy")


# ── Main Content ──────────────────────────────────────────────────────────────
st.markdown('<div class="main-header">Resume Screening AI 🎯</div>', unsafe_allow_html=True)
st.markdown("AI-powered resume analysis using NLP & semantic embeddings")
st.divider()

# ── Job Description Input ─────────────────────────────────────────────────────
st.subheader("📋 Job Description")
jd_text = st.text_area(
    "Paste the full job description here",
    height=200,
    placeholder="""Example:
We are looking for a Senior Python Developer with expertise in machine learning.

Requirements:
- 3+ years of Python development experience
- Strong knowledge of ML frameworks (TensorFlow, PyTorch, scikit-learn)
- Experience with NLP and text processing
- Docker and Kubernetes experience
- Strong communication and teamwork skills""",
    help="Paste the complete job description. More detail = better analysis."
)

st.divider()

# ─────────────────────────────────────────────────────────────────────────────
#  SINGLE RESUME MODE
# ─────────────────────────────────────────────────────────────────────────────
if mode == "Single Resume Analysis":
    st.subheader("📄 Upload Resume")
    uploaded_file = st.file_uploader(
        "Upload a resume (PDF or TXT)",
        type=["pdf", "txt"],
        help="Supports PDF and plain text files."
    )

    if uploaded_file and jd_text.strip():
        if st.button("🚀 Analyze Resume", type="primary", use_container_width=True):
            with st.spinner("Analyzing resume..."):
                try:
                    pipeline = load_pipeline()
                    result = pipeline.analyze_single(
                        uploaded_file.getvalue(),
                        uploaded_file.name,
                        jd_text
                    )

                    st.success("Analysis complete!")
                    st.divider()

                    # ── Score Cards ───────────────────────────────────────────
                    st.subheader("📊 Match Scores")
                    col1, col2, col3 = st.columns(3)

                    with col1:
                        color = result["score_color"]
                        st.markdown(f"""
                        <div class="score-card" style="background:{color}22; border-color:{color}44">
                            <div class="score-number" style="color:{color}">{result['semantic_score']:.0f}%</div>
                            <div class="score-label">Semantic Match</div>
                            <div style="font-size:0.9rem; margin-top:0.3rem; color:{color}; font-weight:600">{result['score_label']}</div>
                        </div>
                        """, unsafe_allow_html=True)

                    with col2:
                        skill_color = "#27AE60" if result['skill_match_rate'] >= 60 else "#E67E22"
                        st.markdown(f"""
                        <div class="score-card" style="background:{skill_color}22; border-color:{skill_color}44">
                            <div class="score-number" style="color:{skill_color}">{result['skill_match_rate']:.0f}%</div>
                            <div class="score-label">Skill Match Rate</div>
                            <div style="font-size:0.9rem; margin-top:0.3rem">{len(result['matched_skills'])} of {result['skill_match_rate']/100*len(result['matched_skills'])+len(result['missing_skills']):.0f} required skills</div>
                        </div>
                        """, unsafe_allow_html=True)

                    with col3:
                        exp_color = "#3498DB"
                        st.markdown(f"""
                        <div class="score-card" style="background:{exp_color}22; border-color:{exp_color}44">
                            <div class="score-number" style="color:{exp_color}">{result['experience_years']:.0f}</div>
                            <div class="score-label">Years of Experience</div>
                            <div style="font-size:0.9rem; margin-top:0.3rem">Detected from resume</div>
                        </div>
                        """, unsafe_allow_html=True)

                    # ── Skill Analysis ────────────────────────────────────────
                    st.divider()
                    st.subheader("🎯 Skill Analysis")

                    tab1, tab2, tab3 = st.tabs(["✅ Matched Skills", "❌ Missing Skills", "➕ Additional Skills"])

                    with tab1:
                        if result["matched_skills"]:
                            html = " ".join([
                                f'<span class="skill-tag skill-matched">{s}</span>'
                                for s in result["matched_skills"]
                            ])
                            st.markdown(html, unsafe_allow_html=True)
                        else:
                            st.info("No matching skills detected between resume and job description.")

                    with tab2:
                        if result["missing_skills"]:
                            html = " ".join([
                                f'<span class="skill-tag skill-missing">{s}</span>'
                                for s in result["missing_skills"]
                            ])
                            st.markdown(html, unsafe_allow_html=True)
                            st.caption("These skills appear in the job description but not in your resume.")
                        else:
                            st.success("No significant skill gaps detected!")

                    with tab3:
                        if result["extra_skills"]:
                            html = " ".join([
                                f'<span class="skill-tag skill-extra">{s}</span>'
                                for s in result["extra_skills"]
                            ])
                            st.markdown(html, unsafe_allow_html=True)
                            st.caption("Skills you have that aren't in the job description — may be valuable for other roles.")
                        else:
                            st.info("No additional skills detected beyond the JD requirements.")

                    # ── Skills by Category Chart ──────────────────────────────
                    if result["resume_skills_by_category"]:
                        st.divider()
                        st.subheader("📈 Skills by Category")
                        cat_data = {
                            cat.replace("_", " ").title(): len(skills)
                            for cat, skills in result["resume_skills_by_category"].items()
                        }
                        fig = px.bar(
                            x=list(cat_data.values()),
                            y=list(cat_data.keys()),
                            orientation="h",
                            color=list(cat_data.values()),
                            color_continuous_scale="Viridis",
                            labels={"x": "Number of Skills", "y": "Category"},
                            title="Skills Detected in Resume by Category"
                        )
                        fig.update_layout(
                            showlegend=False,
                            coloraxis_showscale=False,
                            height=350,
                            margin=dict(l=20, r=20, t=40, b=20)
                        )
                        st.plotly_chart(fig, use_container_width=True)

                    # ── Improvement Suggestions ───────────────────────────────
                    st.divider()
                    st.subheader("💡 Improvement Suggestions")

                    priority_icons = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}
                    priority_class = {
                        "HIGH": "suggestion-high",
                        "MEDIUM": "suggestion-medium",
                        "LOW": "suggestion-low"
                    }

                    for suggestion in result["suggestions"]:
                        p = suggestion["priority"]
                        with st.expander(
                            f"{priority_icons[p]} [{p}] {suggestion['category']}: {suggestion['suggestion'][:60]}..."
                        ):
                            st.markdown(f'<div class="{priority_class[p]}">', unsafe_allow_html=True)
                            st.markdown(f"**Suggestion:** {suggestion['suggestion']}")
                            st.markdown(f"**Why:** {suggestion['reason']}")
                            st.markdown("</div>", unsafe_allow_html=True)

                    # ── Education ─────────────────────────────────────────────
                    if result["education"]:
                        st.divider()
                        st.subheader("🎓 Education Detected")
                        for edu in result["education"]:
                            cols = st.columns([3, 2, 1])
                            with cols[0]:
                                st.markdown(f"**{edu['degree']}**")
                            with cols[1]:
                                st.markdown(edu.get("institution", "—"))
                            with cols[2]:
                                st.markdown(edu.get("year", "—"))

                    # ── Raw Text ──────────────────────────────────────────────
                    with st.expander("📄 View Extracted Resume Text"):
                        st.text_area("Extracted Text", result["resume_text"], height=300)

                except Exception as e:
                    st.error(f"Analysis failed: {str(e)}")
                    st.exception(e)

    else:
        if not jd_text.strip():
            st.info("👆 Please paste a job description above to get started.")
        if not uploaded_file:
            st.info("👆 Please upload a resume file.")

# ─────────────────────────────────────────────────────────────────────────────
#  MULTI-CANDIDATE RANKING MODE
# ─────────────────────────────────────────────────────────────────────────────
else:
    st.subheader("📁 Upload Multiple Resumes")
    uploaded_files = st.file_uploader(
        "Upload resumes (PDF or TXT) — upload multiple at once",
        type=["pdf", "txt"],
        accept_multiple_files=True,
        help="Upload all candidate resumes. They will be ranked against the job description."
    )

    if uploaded_files:
        st.info(f"✅ {len(uploaded_files)} resume(s) uploaded: {', '.join(f.name for f in uploaded_files)}")

    if uploaded_files and jd_text.strip():
        if st.button("🏆 Rank All Candidates", type="primary", use_container_width=True):
            with st.spinner(f"Analyzing and ranking {len(uploaded_files)} candidates..."):
                try:
                    pipeline = load_pipeline()
                    resume_inputs = [
                        (f.getvalue(), f.name) for f in uploaded_files
                    ]
                    ranked = pipeline.rank_candidates(resume_inputs, jd_text)

                    st.success(f"Ranking complete! Analyzed {len(ranked)} candidates.")
                    st.divider()

                    # ── Leaderboard Table ─────────────────────────────────────
                    st.subheader("🏆 Candidate Leaderboard")

                    leaderboard_data = []
                    for c in ranked:
                        leaderboard_data.append({
                            "Rank": f"#{c['rank']}",
                            "Candidate": c["name"].replace(".pdf", "").replace(".txt", ""),
                            "Composite Score": f"{c['composite_score']:.1f}%",
                            "Semantic Match": f"{c['score_breakdown']['semantic_similarity']:.1f}%",
                            "Skill Match": f"{c['score_breakdown']['skill_match']:.1f}%",
                            "Experience Score": f"{c['score_breakdown']['experience']:.1f}%",
                            "Label": c.get("score_label", "")
                        })

                    df = pd.DataFrame(leaderboard_data)
                    st.dataframe(
                        df,
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            "Rank": st.column_config.TextColumn(width="small"),
                            "Composite Score": st.column_config.TextColumn(width="medium"),
                        }
                    )

                    # ── Score Comparison Chart ────────────────────────────────
                    st.divider()
                    st.subheader("📊 Score Comparison")

                    names = [c["name"].replace(".pdf", "").replace(".txt", "") for c in ranked]
                    fig = go.Figure()
                    fig.add_trace(go.Bar(
                        name="Semantic Match",
                        x=names,
                        y=[c["score_breakdown"]["semantic_similarity"] for c in ranked],
                        marker_color="#667eea"
                    ))
                    fig.add_trace(go.Bar(
                        name="Skill Match",
                        x=names,
                        y=[c["score_breakdown"]["skill_match"] for c in ranked],
                        marker_color="#764ba2"
                    ))
                    fig.add_trace(go.Bar(
                        name="Experience",
                        x=names,
                        y=[c["score_breakdown"]["experience"] for c in ranked],
                        marker_color="#f5a623"
                    ))
                    fig.update_layout(
                        barmode="group",
                        xaxis_title="Candidate",
                        yaxis_title="Score (%)",
                        yaxis_range=[0, 100],
                        height=400,
                        legend=dict(orientation="h", yanchor="bottom", y=1.02)
                    )
                    st.plotly_chart(fig, use_container_width=True)

                    # ── Radar Chart for Top 3 ─────────────────────────────────
                    if len(ranked) >= 2:
                        st.divider()
                        st.subheader("🎯 Top Candidates — Radar Comparison")

                        top3 = ranked[:min(3, len(ranked))]
                        categories = ["Semantic Match", "Skill Match", "Experience"]

                        fig2 = go.Figure()
                        colors = ["#667eea", "#764ba2", "#f5a623"]

                        for i, c in enumerate(top3):
                            values = [
                                c["score_breakdown"]["semantic_similarity"],
                                c["score_breakdown"]["skill_match"],
                                c["score_breakdown"]["experience"],
                            ]
                            values += [values[0]]  # Close the radar polygon

                            fig2.add_trace(go.Scatterpolar(
                                r=values,
                                theta=categories + [categories[0]],
                                fill="toself",
                                name=c["name"].replace(".pdf", "").replace(".txt", ""),
                                line_color=colors[i],
                                fillcolor=colors[i],
                                opacity=0.3
                            ))

                        fig2.update_layout(
                            polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
                            showlegend=True,
                            height=450
                        )
                        st.plotly_chart(fig2, use_container_width=True)

                    # ── Individual Cards ──────────────────────────────────────
                    st.divider()
                    st.subheader("👤 Candidate Details")

                    for c in ranked:
                        medal = ["🥇", "🥈", "🥉"][c["rank"] - 1] if c["rank"] <= 3 else f"#{c['rank']}"
                        with st.expander(
                            f"{medal} {c['name']} — {c['composite_score']:.1f}% composite score"
                        ):
                            col1, col2 = st.columns(2)
                            with col1:
                                st.metric("Semantic Match", f"{c['score_breakdown']['semantic_similarity']:.1f}%")
                                st.metric("Skill Match", f"{c['score_breakdown']['skill_match']:.1f}%")
                            with col2:
                                st.metric("Experience Score", f"{c['score_breakdown']['experience']:.1f}%")
                                st.metric("Experience Years", f"{c.get('experience_years', 0):.0f} yrs")

                            if c.get("matched_skills"):
                                st.markdown("**Matched Skills:**")
                                html = " ".join([
                                    f'<span class="skill-tag skill-matched">{s}</span>'
                                    for s in c["matched_skills"][:8]
                                ])
                                st.markdown(html, unsafe_allow_html=True)

                            if c.get("missing_skills"):
                                st.markdown("**Top Missing Skills:**")
                                html = " ".join([
                                    f'<span class="skill-tag skill-missing">{s}</span>'
                                    for s in c["missing_skills"][:5]
                                ])
                                st.markdown(html, unsafe_allow_html=True)

                except Exception as e:
                    st.error(f"Ranking failed: {str(e)}")
                    st.exception(e)
    else:
        if not jd_text.strip():
            st.info("👆 Paste a job description above.")
        if not uploaded_files:
            st.info("👆 Upload one or more resume files.")

# ── Footer ─────────────────────────────────────────────────────────────────────
st.divider()
st.markdown("""
<div style="text-align:center; opacity:0.5; font-size:0.8rem">
    Resume Screening AI • Built with Streamlit, Sentence-BERT, spaCy • For educational & portfolio use
</div>
""", unsafe_allow_html=True)
