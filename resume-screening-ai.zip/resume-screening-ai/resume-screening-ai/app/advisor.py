"""
advisor.py
----------
Generates actionable resume improvement suggestions based on:
  1. Missing skills identified in the skill gap analysis
  2. Semantic similarity score (too low = weak language alignment)
  3. Experience signals (years, job titles, action verbs)
  4. Structure quality heuristics (sections detected, length)

This is a rule-based advisor. In a production system, you could
replace or augment this with an LLM (e.g., GPT-4, Claude) for
more nuanced and personalized feedback.
"""

from typing import List, Dict


# Strong action verbs commonly found in high-scoring resumes
STRONG_ACTION_VERBS = [
    "achieved", "built", "created", "delivered", "designed", "developed",
    "drove", "engineered", "established", "executed", "improved", "increased",
    "launched", "led", "managed", "optimized", "reduced", "scaled",
    "shipped", "spearheaded", "streamlined", "transformed"
]

# Common resume sections expected by ATS systems
EXPECTED_SECTIONS = [
    "experience", "education", "skills", "projects", "summary", "objective"
]


class ResumeAdvisor:
    """
    Analyzes resume quality and generates improvement recommendations.
    """

    def generate_suggestions(
        self,
        resume_text: str,
        semantic_score: float,
        skill_gap: Dict,
        experience_years: float
    ) -> List[Dict]:
        """
        Generate a prioritized list of improvement suggestions.

        Args:
            resume_text: Raw extracted resume text.
            semantic_score: Cosine similarity % against the job description.
            skill_gap: Output from SkillExtractor.compute_skill_gap().
            experience_years: Extracted years of experience.

        Returns:
            List of suggestion dicts, each with:
                - priority: "HIGH", "MEDIUM", or "LOW"
                - category: Type of suggestion
                - suggestion: Actionable text
                - reason: Why this helps
        """
        suggestions = []

        # --- Skill Gap Suggestions (HIGH priority) ---
        missing = skill_gap.get("missing_skills", [])
        if missing:
            top_missing = missing[:5]  # Focus on top 5 most impactful
            suggestions.append({
                "priority": "HIGH",
                "category": "Missing Skills",
                "suggestion": f"Add these skills to your resume: {', '.join(top_missing)}",
                "reason": (
                    "These skills appear in the job description but not your resume. "
                    "Even if you have them, ATS systems and recruiters won't know."
                )
            })

        # --- Semantic Score Suggestions ---
        if semantic_score < 50:
            suggestions.append({
                "priority": "HIGH",
                "category": "Language Alignment",
                "suggestion": (
                    "Rewrite your resume summary and experience bullets to mirror "
                    "the language and keywords used in the job description."
                ),
                "reason": (
                    f"Your semantic match score is {semantic_score:.0f}%. "
                    "Low scores mean your resume language doesn't align with what "
                    "the employer is looking for. Use their exact terminology."
                )
            })
        elif semantic_score < 65:
            suggestions.append({
                "priority": "MEDIUM",
                "category": "Language Alignment",
                "suggestion": (
                    "Tailor your summary section to directly address the role's "
                    "requirements. Match the tone and vocabulary of the job posting."
                ),
                "reason": (
                    f"Your match score is {semantic_score:.0f}%. "
                    "Small language improvements can significantly boost ATS rankings."
                )
            })

        # --- Action Verb Analysis ---
        resume_lower = resume_text.lower()
        found_verbs = [v for v in STRONG_ACTION_VERBS if v in resume_lower]
        if len(found_verbs) < 5:
            suggestions.append({
                "priority": "MEDIUM",
                "category": "Impact Language",
                "suggestion": (
                    "Start your bullet points with strong action verbs like: "
                    "achieved, built, delivered, drove, improved, launched, led, "
                    "optimized, reduced, scaled, shipped."
                ),
                "reason": (
                    "Action-oriented language makes your experience sound impactful "
                    "rather than passive. Recruiters scan for these words."
                )
            })

        # --- Quantification Check ---
        import re
        numbers_in_resume = re.findall(r'\b\d+[%x]?\b', resume_text)
        if len(numbers_in_resume) < 3:
            suggestions.append({
                "priority": "MEDIUM",
                "category": "Quantify Achievements",
                "suggestion": (
                    "Add measurable results to your experience bullets. "
                    "Examples: 'Reduced load time by 40%', 'Led team of 8 engineers', "
                    "'Increased revenue by $2M'."
                ),
                "reason": (
                    "Quantified achievements are 3x more compelling than vague statements. "
                    "They also improve semantic matching with result-oriented job descriptions."
                )
            })

        # --- Section Structure Check ---
        missing_sections = []
        for section in EXPECTED_SECTIONS:
            if section not in resume_lower:
                missing_sections.append(section)

        if missing_sections:
            suggestions.append({
                "priority": "LOW",
                "category": "Resume Structure",
                "suggestion": (
                    f"Consider adding these standard sections: "
                    f"{', '.join(s.title() for s in missing_sections)}"
                ),
                "reason": (
                    "ATS systems and recruiters expect a clear structure. "
                    "Missing sections can cause automatic disqualification."
                )
            })

        # --- Length Check ---
        word_count = len(resume_text.split())
        if word_count < 200:
            suggestions.append({
                "priority": "MEDIUM",
                "category": "Content Depth",
                "suggestion": (
                    "Your resume appears short. Aim for at least 400-600 words. "
                    "Add more detail to your experience bullets and projects."
                ),
                "reason": (
                    f"Your resume has approximately {word_count} words. "
                    "Thin resumes give AI systems and recruiters less signal to evaluate."
                )
            })
        elif word_count > 1200:
            suggestions.append({
                "priority": "LOW",
                "category": "Conciseness",
                "suggestion": (
                    "Consider trimming your resume to 1-2 pages. "
                    "Focus on the last 5-7 years and most relevant experience."
                ),
                "reason": (
                    "Recruiters spend an average of 7 seconds on a first scan. "
                    "Overly long resumes can dilute your strongest points."
                )
            })

        # --- Experience Gap ---
        if experience_years == 0:
            suggestions.append({
                "priority": "LOW",
                "category": "Experience Visibility",
                "suggestion": (
                    "Make sure your work history includes clear date ranges "
                    "(e.g., 'Jan 2020 – Dec 2023') so automated tools can calculate "
                    "your experience level."
                ),
                "reason": (
                    "Unclear dates make it impossible for ATS systems to assess "
                    "your seniority level accurately."
                )
            })

        # Sort by priority: HIGH first, then MEDIUM, then LOW
        priority_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        suggestions.sort(key=lambda x: priority_order[x["priority"]])

        return suggestions
