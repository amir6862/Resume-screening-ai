"""
skill_extractor.py
------------------
Extracts skills, education, and experience from resumes
using a combination of:
  1. Keyword matching against a curated skills database
  2. spaCy Named Entity Recognition (NER) for names, orgs, dates
  3. Pattern-based section parsing (Education, Experience)

Named Entity Recognition (NER):
    NER identifies and classifies named entities in text:
    - PERSON   -> "John Doe"
    - ORG      -> "Google", "MIT"
    - DATE     -> "2019-2023", "3 years"
    - GPE      -> Locations / Countries

    We extend this with custom patterns for skills.
"""

import re
import json
import spacy
from pathlib import Path
from typing import List, Dict, Set


# Built-in skills database (no file needed)
# Organized by category for structured output
SKILLS_DATABASE = {
    "programming_languages": [
        "python", "java", "javascript", "typescript", "c++", "c#", "ruby",
        "go", "rust", "kotlin", "swift", "scala", "r", "matlab", "php",
        "perl", "bash", "shell", "powershell", "sql", "plsql", "cobol"
    ],
    "ml_ai": [
        "machine learning", "deep learning", "neural network", "nlp",
        "natural language processing", "computer vision", "reinforcement learning",
        "tensorflow", "pytorch", "keras", "scikit-learn", "hugging face",
        "bert", "gpt", "transformer", "opencv", "pandas", "numpy",
        "xgboost", "lightgbm", "random forest", "regression", "classification",
        "clustering", "time series", "feature engineering"
    ],
    "web_development": [
        "react", "angular", "vue", "nextjs", "nodejs", "express", "django",
        "flask", "fastapi", "spring", "laravel", "html", "css", "sass",
        "tailwind", "bootstrap", "graphql", "rest api", "restful",
        "websocket", "nginx", "apache"
    ],
    "databases": [
        "sql", "mysql", "postgresql", "mongodb", "redis", "elasticsearch",
        "cassandra", "dynamodb", "sqlite", "oracle", "firebase",
        "bigquery", "snowflake", "dbt"
    ],
    "cloud_devops": [
        "aws", "azure", "gcp", "google cloud", "docker", "kubernetes",
        "terraform", "ansible", "jenkins", "github actions", "ci/cd",
        "linux", "unix", "microservices", "serverless", "lambda",
        "s3", "ec2", "rds"
    ],
    "soft_skills": [
        "leadership", "communication", "teamwork", "problem solving",
        "project management", "agile", "scrum", "kanban", "mentoring",
        "collaboration", "analytical", "critical thinking"
    ],
    "data_engineering": [
        "spark", "hadoop", "kafka", "airflow", "etl", "data pipeline",
        "data warehouse", "data lake", "flink", "hive", "presto"
    ]
}


class SkillExtractor:
    """
    Extracts structured information from resume text:
    - Technical and soft skills
    - Education (degrees, institutions, years)
    - Work experience (job titles, companies, durations)
    """

    def __init__(self, skills_db: Dict = None):
        """
        Args:
            skills_db: Optional custom skills database dict.
                       Uses built-in SKILLS_DATABASE if not provided.
        """
        self.nlp = spacy.load("en_core_web_sm")
        self.skills_db = skills_db or SKILLS_DATABASE

        # Flatten all skills into a single searchable set
        self.all_skills: Set[str] = set()
        for category_skills in self.skills_db.values():
            self.all_skills.update(s.lower() for s in category_skills)

        # Compile regex patterns for efficiency
        self._education_pattern = re.compile(
            r"(bachelor|master|phd|ph\.d|doctorate|b\.s|m\.s|b\.e|m\.e|"
            r"b\.tech|m\.tech|mba|associate|diploma)\s*"
            r"(?:of|in|'s)?\s*([a-z\s]+)?",
            re.IGNORECASE
        )
        self._year_pattern = re.compile(r'\b(19|20)\d{2}\b')

    def extract_skills(self, text: str) -> Dict[str, List[str]]:
        """
        Extract all skills from text, organized by category.

        Args:
            text: Raw or preprocessed resume text.

        Returns:
            Dict mapping category -> list of found skills.
            Example: {"programming_languages": ["python", "java"], ...}
        """
        text_lower = text.lower()
        found_by_category: Dict[str, List[str]] = {}

        for category, skills in self.skills_db.items():
            found = []
            for skill in skills:
                skill_lower = skill.lower()
                # Use word-boundary matching to avoid false positives
                # e.g., "r" shouldn't match in "framework"
                if len(skill_lower) <= 2:
                    # Short skills: require word boundaries
                    pattern = r'\b' + re.escape(skill_lower) + r'\b'
                    if re.search(pattern, text_lower):
                        found.append(skill)
                else:
                    # Longer skills: simple substring match is fine
                    if skill_lower in text_lower:
                        found.append(skill)

            if found:
                found_by_category[category] = found

        return found_by_category

    def extract_all_skills_flat(self, text: str) -> List[str]:
        """
        Extract all skills as a flat list (no categories).
        Used for gap analysis comparison.
        """
        by_category = self.extract_skills(text)
        flat = []
        for skills in by_category.values():
            flat.extend(skills)
        return list(set(flat))  # deduplicate

    def extract_education(self, text: str) -> List[Dict]:
        """
        Extract education entries from resume text.

        Returns:
            List of dicts: [{"degree": ..., "institution": ..., "year": ...}]
        """
        doc = self.nlp(text[:50000])
        education_entries = []

        # Find organizations (potential universities)
        orgs = [ent.text for ent in doc.ents if ent.label_ == "ORG"]

        # Find degree mentions
        degree_matches = self._education_pattern.finditer(text)

        for match in degree_matches:
            degree = match.group(0).strip()

            # Find a year near this degree mention
            start = max(0, match.start() - 200)
            end = min(len(text), match.end() + 200)
            surrounding = text[start:end]
            years = self._year_pattern.findall(surrounding)

            # Try to find a nearby organization
            institution = ""
            for org in orgs:
                if org.lower() in surrounding.lower():
                    institution = org
                    break

            education_entries.append({
                "degree": degree,
                "institution": institution,
                "year": years[0] if years else "N/A"
            })

        return education_entries[:5]  # Return top 5 matches

    def extract_experience_years(self, text: str) -> float:
        """
        Estimate total years of work experience from resume text.

        Strategy:
        1. Find all 4-digit years in the text
        2. Calculate span from earliest to latest year
        3. Look for explicit "X years of experience" phrases

        Returns:
            Estimated years of experience as float.
        """
        # Strategy 1: explicit "N years" mentions
        years_pattern = re.compile(
            r'(\d+)\+?\s*years?\s*(?:of\s*)?(?:experience|exp)',
            re.IGNORECASE
        )
        explicit_matches = years_pattern.findall(text)
        if explicit_matches:
            # Return the largest explicit claim
            return float(max(int(y) for y in explicit_matches))

        # Strategy 2: year range calculation
        years_found = [int(y) for y in self._year_pattern.findall(text)]
        if len(years_found) >= 2:
            year_span = max(years_found) - min(years_found)
            # Cap at 40 to ignore birth year misdetections
            if year_span <= 40:
                return float(year_span)

        return 0.0

    def compute_skill_gap(
        self,
        resume_skills: List[str],
        jd_skills: List[str]
    ) -> Dict:
        """
        Compare resume skills against job description skills.

        Args:
            resume_skills: Skills found in the resume.
            jd_skills: Skills required by the job description.

        Returns:
            Dict with matched_skills, missing_skills, and match_rate.
        """
        resume_set = set(s.lower() for s in resume_skills)
        jd_set = set(s.lower() for s in jd_skills)

        matched = resume_set.intersection(jd_set)
        missing = jd_set - resume_set
        extra = resume_set - jd_set  # skills in resume not in JD

        match_rate = (len(matched) / len(jd_set) * 100) if jd_set else 0.0

        return {
            "matched_skills": sorted(matched),
            "missing_skills": sorted(missing),
            "extra_skills": sorted(extra),
            "skill_match_rate": round(match_rate, 1),
            "total_jd_skills": len(jd_set),
            "total_resume_skills": len(resume_set)
        }
