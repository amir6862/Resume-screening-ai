"""
preprocessor.py
---------------
NLP text preprocessing pipeline.

Concepts covered:
- Tokenization: splitting text into words/sentences
- Stopword removal: removing common words ("the", "is", "and")
- Lemmatization: reducing words to root form ("running" -> "run")
- Text normalization: lowercasing, punctuation removal
"""

import re
import spacy
from typing import List


class TextPreprocessor:
    """
    Cleans and normalizes resume and job description text
    for embedding and keyword matching.
    """

    def __init__(self):
        # Load spaCy's English model
        # en_core_web_sm is fast; use en_core_web_lg for better accuracy
        self.nlp = spacy.load("en_core_web_sm")

        # Custom stopwords we want to KEEP for resumes
        # (spaCy removes these by default but they matter in job context)
        self.keep_words = {"not", "no", "never", "without"}
        for word in self.keep_words:
            self.nlp.vocab[word].is_stop = False

    def clean(self, text: str) -> str:
        """
        Full preprocessing pipeline.
        Returns a clean, normalized string ready for embedding.

        Pipeline:
        1. Lowercase
        2. Remove URLs, emails, phone numbers
        3. Remove special characters (keep letters/numbers/spaces)
        4. Tokenize and lemmatize via spaCy
        5. Remove stopwords
        6. Rejoin tokens
        """
        text = text.lower()
        text = self._remove_noise(text)
        tokens = self._tokenize_and_lemmatize(text)
        tokens = self._remove_stopwords(tokens)
        return " ".join(tokens)

    def clean_for_display(self, text: str) -> str:
        """
        Lighter cleaning — preserves readability for display.
        Used when we show extracted text to the user.
        """
        text = self._remove_noise(text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def extract_sentences(self, text: str) -> List[str]:
        """
        Split text into individual sentences using spaCy's sentence detector.
        Useful for section-level analysis.
        """
        doc = self.nlp(text[:100000])  # spaCy limit safety
        return [sent.text.strip() for sent in doc.sents if sent.text.strip()]

    def _remove_noise(self, text: str) -> str:
        """Remove URLs, emails, phone numbers, and special symbols."""
        text = re.sub(r'https?://\S+|www\.\S+', '', text)
        text = re.sub(r'\S+@\S+\.\S+', '', text)
        text = re.sub(r'[\+\(]?[1-9][0-9\-\(\)\s]{7,}[0-9]', '', text)
        text = re.sub(r'^[\•\-\*\>]\s*', '', text, flags=re.MULTILINE)
        return text

    def _tokenize_and_lemmatize(self, text: str) -> List[str]:
        """
        Use spaCy to tokenize and lemmatize.
        Lemmatization converts words to base form:
        "managed", "managing", "manages" -> "manage"
        """
        doc = self.nlp(text[:100000])
        tokens = []
        for token in doc:
            if token.is_alpha and len(token.text) > 1:
                tokens.append(token.lemma_)
        return tokens

    def _remove_stopwords(self, tokens: List[str]) -> List[str]:
        """Remove common words that add no semantic value."""
        return [
            token for token in tokens
            if not self.nlp.vocab[token].is_stop
        ]
