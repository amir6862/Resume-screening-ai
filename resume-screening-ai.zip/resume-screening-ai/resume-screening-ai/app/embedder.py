"""
embedder.py
-----------
Generates semantic embeddings using Sentence-BERT (SBERT).

Key Concept:
    Embeddings are dense numerical vectors that capture the *meaning*
    of text. Two sentences with similar meaning will have embeddings
    close together in vector space, even if they use different words.

    Example:
        "Python developer with ML experience"
        "Machine learning engineer skilled in Python"
        -> These produce very similar vectors (high cosine similarity)

    Model used: all-MiniLM-L6-v2
        - 384-dimensional vectors
        - Fast (6x faster than BERT-base)
        - High quality for semantic similarity tasks
        - ~80MB download on first use (cached locally after)
"""

import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Union


class ResumeEmbedder:
    """
    Converts text into semantic embedding vectors using Sentence-BERT.
    """

    # Recommended models (trade-off: speed vs quality)
    MODELS = {
        "fast":    "all-MiniLM-L6-v2",       # 384-dim, ~80MB, best for most use cases
        "balanced":"all-mpnet-base-v2",        # 768-dim, ~420MB, better quality
        "quality": "paraphrase-multilingual-mpnet-base-v2",  # multilingual support
    }

    def __init__(self, model_name: str = "fast"):
        """
        Initialize the embedding model.

        Args:
            model_name: One of 'fast', 'balanced', or 'quality'.
                        Or pass any valid sentence-transformers model name.
        """
        # Resolve alias to full model name
        resolved = self.MODELS.get(model_name, model_name)
        print(f"Loading embedding model: {resolved}")
        print("(First run downloads ~80MB — cached for future use)")
        self.model = SentenceTransformer(resolved)
        self.model_name = resolved

    def embed(self, text: str) -> np.ndarray:
        """
        Generate a single embedding vector for a text string.

        Args:
            text: Input string (resume or job description).

        Returns:
            numpy array of shape (384,) for MiniLM or (768,) for mpnet.
        """
        if not text or not text.strip():
            raise ValueError("Cannot embed empty text.")

        # encode() returns a numpy array
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding

    def embed_batch(self, texts: List[str]) -> np.ndarray:
        """
        Generate embeddings for multiple texts efficiently (batched).
        Much faster than calling embed() in a loop.

        Args:
            texts: List of text strings.

        Returns:
            numpy array of shape (N, embedding_dim).
        """
        if not texts:
            raise ValueError("texts list cannot be empty.")

        # batch_size=32 is a good default; increase if you have GPU
        embeddings = self.model.encode(
            texts,
            batch_size=32,
            convert_to_numpy=True,
            show_progress_bar=len(texts) > 10  # show progress for large batches
        )
        return embeddings

    def get_embedding_dim(self) -> int:
        """Return the dimensionality of the embedding vectors."""
        return self.model.get_sentence_embedding_dimension()
