"""
scorer.py
---------
Computes match scores between resumes and job descriptions
using cosine similarity on embedding vectors.

Key Concept — Cosine Similarity:
    Measures the angle between two vectors (not their magnitude).
    Range: -1 (opposite) to +1 (identical meaning)
    For text: typically 0.0 to 1.0

    Formula:
        similarity = dot(A, B) / (||A|| * ||B||)

    Why cosine and not Euclidean distance?
        Because cosine ignores length — a short resume and a long resume
        with the same skills should score equally, not differently.
"""

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from typing import Tuple


class MatchScorer:
    """
    Scores resume-to-job-description match using cosine similarity.
    Returns a percentage score (0-100).
    """

    def score(
        self,
        resume_embedding: np.ndarray,
        jd_embedding: np.ndarray
    ) -> float:
        """
        Compute the cosine similarity between a resume and a job description.

        Args:
            resume_embedding: Embedding vector of the resume.
            jd_embedding: Embedding vector of the job description.

        Returns:
            Float between 0 and 100 representing the match percentage.
        """
        # sklearn expects 2D arrays: reshape (384,) -> (1, 384)
        resume_vec = resume_embedding.reshape(1, -1)
        jd_vec = jd_embedding.reshape(1, -1)

        # cosine_similarity returns a 2D array [[score]]
        raw_score = cosine_similarity(resume_vec, jd_vec)[0][0]

        # Convert from [-1, 1] range to [0, 100] percentage
        # In practice, text similarity is always > 0, but we clamp to be safe
        percentage = max(0.0, min(100.0, raw_score * 100))

        return round(percentage, 2)

    def score_with_label(
        self,
        resume_embedding: np.ndarray,
        jd_embedding: np.ndarray
    ) -> Tuple[float, str]:
        """
        Compute score AND return a human-readable quality label.

        Returns:
            Tuple of (score_percentage, label_string)
        """
        score = self.score(resume_embedding, jd_embedding)
        label = self._get_label(score)
        return score, label

    def _get_label(self, score: float) -> str:
        """Convert a numeric score to a descriptive label."""
        if score >= 80:
            return "Excellent Match"
        elif score >= 65:
            return "Strong Match"
        elif score >= 50:
            return "Good Match"
        elif score >= 35:
            return "Partial Match"
        else:
            return "Low Match"

    def get_score_color(self, score: float) -> str:
        """Return a color hex code for UI display based on score."""
        if score >= 80:
            return "#27AE60"   # Green
        elif score >= 65:
            return "#2ECC71"   # Light green
        elif score >= 50:
            return "#F39C12"   # Orange
        elif score >= 35:
            return "#E67E22"   # Dark orange
        else:
            return "#E74C3C"   # Red
