"""
pipeline.py
-----------
Orchestrates the full resume screening pipeline.

This is the main entry point for the AI system.
It chains together all modules:
  Extractor -> Preprocessor -> Embedder -> Scorer
           -> SkillExtractor -> Advisor -> Ranker

Usage:
    pipeline = ScreeningPipeline()
    result = pipeline.analyze_single(resume_bytes, "resume.pdf", jd_text)
    ranked = pipeline.rank_candidates(resume_files, jd_text)
"""

from typing import List, Dict, Tuple
from .extractor import ResumeExtractor
from .preprocessor import TextPreprocessor
from .embedder import ResumeEmbedder
from .scorer import MatchScorer
from .skill_extractor import SkillExtractor
from .advisor import ResumeAdvisor
from .ranker import CandidateRanker


class ScreeningPipeline:
    """
    End-to-end resume screening pipeline.
    Initializes all modules once and reuses them for efficiency.
    """

    def __init__(self, embedding_model: str = "fast"):
        """
        Initialize all pipeline components.

        Args:
            embedding_model: 'fast', 'balanced', or 'quality'.
                             See embedder.py for details.
        """
        print("Initializing Resume Screening AI Pipeline...")
        self.extractor = ResumeExtractor()
        self.preprocessor = TextPreprocessor()
        self.embedder = ResumeEmbedder(model_name=embedding_model)
        self.scorer = MatchScorer()
        self.skill_extractor = SkillExtractor()
        self.advisor = ResumeAdvisor()
        self.ranker = CandidateRanker()
        print("Pipeline ready.\n")

    def analyze_single(
        self,
        resume_input,        # bytes or str (file path)
        resume_name: str,    # filename for type detection
        jd_text: str         # raw job description text
    ) -> Dict:
        """
        Full analysis of a single resume against a job description.

        Args:
            resume_input: Either bytes (from Streamlit) or str (file path).
            resume_name: Filename like "john_doe.pdf".
            jd_text: Raw job description text.

        Returns:
            Dict with complete analysis results.
        """
        # ── Step 1: Extract text ──────────────────────────────────────
        if isinstance(resume_input, bytes):
            resume_text = self.extractor.extract_from_bytes(resume_input, resume_name)
        else:
            resume_text = self.extractor.extract(resume_input)

        # ── Step 2: Preprocess ────────────────────────────────────────
        resume_clean = self.preprocessor.clean(resume_text)
        jd_clean = self.preprocessor.clean(jd_text)

        # ── Step 3: Generate embeddings ───────────────────────────────
        resume_embedding = self.embedder.embed(resume_clean)
        jd_embedding = self.embedder.embed(jd_clean)

        # ── Step 4: Compute semantic score ────────────────────────────
        semantic_score, label = self.scorer.score_with_label(
            resume_embedding, jd_embedding
        )

        # ── Step 5: Extract skills ────────────────────────────────────
        resume_skills = self.skill_extractor.extract_all_skills_flat(resume_text)
        jd_skills = self.skill_extractor.extract_all_skills_flat(jd_text)
        resume_skills_by_category = self.skill_extractor.extract_skills(resume_text)

        # ── Step 6: Skill gap analysis ────────────────────────────────
        skill_gap = self.skill_extractor.compute_skill_gap(resume_skills, jd_skills)

        # ── Step 7: Extract experience and education ──────────────────
        experience_years = self.skill_extractor.extract_experience_years(resume_text)
        education = self.skill_extractor.extract_education(resume_text)

        # ── Step 8: Generate improvement suggestions ──────────────────
        suggestions = self.advisor.generate_suggestions(
            resume_text, semantic_score, skill_gap, experience_years
        )

        return {
            "name": resume_name,
            "resume_text": resume_text,          # Raw extracted text
            "semantic_score": semantic_score,
            "score_label": label,
            "score_color": self.scorer.get_score_color(semantic_score),
            "skill_match_rate": skill_gap["skill_match_rate"],
            "matched_skills": skill_gap["matched_skills"],
            "missing_skills": skill_gap["missing_skills"],
            "extra_skills": skill_gap["extra_skills"],
            "resume_skills_by_category": resume_skills_by_category,
            "experience_years": experience_years,
            "education": education,
            "suggestions": suggestions,
            # Used by ranker
            "skill_gap": skill_gap,
        }

    def rank_candidates(
        self,
        resume_inputs: List[Tuple],   # List of (bytes_or_path, filename)
        jd_text: str
    ) -> List[Dict]:
        """
        Analyze and rank multiple candidates.

        Args:
            resume_inputs: List of (resume_data, filename) tuples.
            jd_text: Raw job description text.

        Returns:
            Sorted list of analysis results (best candidate first).
        """
        print(f"Analyzing {len(resume_inputs)} candidates...")
        analyses = []

        for resume_data, filename in resume_inputs:
            print(f"  Processing: {filename}")
            try:
                result = self.analyze_single(resume_data, filename, jd_text)
                analyses.append(result)
            except Exception as e:
                print(f"  ERROR processing {filename}: {e}")
                continue

        # Rank the candidates
        ranked = self.ranker.rank(analyses)

        print(f"\nRanking complete. Top candidate: {ranked[0]['name']}")
        return ranked
