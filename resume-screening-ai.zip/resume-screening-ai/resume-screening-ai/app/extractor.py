"""
extractor.py
------------
Handles all file input: PDFs (via PyMuPDF) and plain text.
Designed to be robust — handles multi-page PDFs, encoding issues,
and malformed files gracefully.
"""

import fitz  # PyMuPDF
import re
from pathlib import Path


class ResumeExtractor:
    """
    Extracts raw text from resume files.
    Supports: PDF, TXT formats.
    """

    def extract(self, file_path: str) -> str:
        """
        Main entry point. Auto-detects file type and extracts text.

        Args:
            file_path: Absolute or relative path to the resume file.

        Returns:
            Cleaned raw text string from the resume.

        Raises:
            ValueError: If the file type is unsupported.
            FileNotFoundError: If the file does not exist.
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        extension = path.suffix.lower()

        if extension == ".pdf":
            return self._extract_from_pdf(str(path))
        elif extension == ".txt":
            return self._extract_from_txt(str(path))
        else:
            raise ValueError(f"Unsupported file type: {extension}. Use PDF or TXT.")

    def extract_from_bytes(self, file_bytes: bytes, filename: str) -> str:
        """
        Extract text directly from in-memory bytes (used by Streamlit uploader).

        Args:
            file_bytes: Raw bytes of the uploaded file.
            filename: Original filename (used to detect type).

        Returns:
            Extracted text string.
        """
        extension = Path(filename).suffix.lower()

        if extension == ".pdf":
            return self._extract_pdf_from_bytes(file_bytes)
        elif extension == ".txt":
            return file_bytes.decode("utf-8", errors="ignore")
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    def _extract_from_pdf(self, file_path: str) -> str:
        """Extract text from a PDF file using PyMuPDF."""
        text_parts = []

        with fitz.open(file_path) as doc:
            for page in doc:
                page_text = page.get_text("text")
                if page_text.strip():
                    text_parts.append(page_text)

        full_text = "\n".join(text_parts)
        return self._clean_extracted_text(full_text)

    def _extract_pdf_from_bytes(self, file_bytes: bytes) -> str:
        """Extract text from PDF bytes (Streamlit upload)."""
        text_parts = []

        with fitz.open(stream=file_bytes, filetype="pdf") as doc:
            for page in doc:
                page_text = page.get_text("text")
                if page_text.strip():
                    text_parts.append(page_text)

        full_text = "\n".join(text_parts)
        return self._clean_extracted_text(full_text)

    def _extract_from_txt(self, file_path: str) -> str:
        """Extract text from a plain text file."""
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    def _clean_extracted_text(self, text: str) -> str:
        """
        Basic cleanup after PDF extraction.
        Removes excessive whitespace while preserving structure.
        """
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'[^\x09\x0A\x0D\x20-\x7E\u00A0-\uFFFF]', '', text)
        return text.strip()
