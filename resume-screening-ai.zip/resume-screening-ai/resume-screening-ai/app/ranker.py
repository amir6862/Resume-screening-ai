"""
ranker.py
---------
Ranks multiple candidates against a job description.

Scoring Formula (Weighted Composite):
    final_score = (
        0.60 * semantic_similarity_score  +  # Embedding cosine similarity
        0.25 * skill_match_rate           +  # % of required skills present
        0.15 * experience_score              # Normalized years of experience
    )

    Weights are tunable — HR teams often want different priorities.
    For senior roles: increase experience_weight.
    For technical roles: increase skill_match_weight.
"""

from typing import List, Dict
import numpy as np


class CandidateRanker:
    """
    Ranks a pool of candidates against a job description.
    Produces a sorted leaderboard with detailed breakdown.
    """

    def __init__(
        self,
        semantic_weight: float = 0.60,
        skill_weight: float = 0.25,
        experience_weight: float = 0.15
    ):
        """
        Args:
            semantic_weight: Weight for embedding cosine similarity score.
            skill_weight: Weight for skill keyword match rate.
            experience_weight: Weight for experience years score.

        Note: Weights must sum to 1.0
        """
        total = semantic_weight + skill_weight + experience_weight
        assert abs(total - 1.0) < 0.001, f"Weights must sum to 1.0, got {total}"

        self.semantic_weight = semantic_weight
        self.skill_weight = skill_weight
        self.experience_weight = experience_weight

    def rank(self, candidates: List[Dict]) -> List[Dict]:
        """
        Rank a list of candidate analysis results.

        Args:
            candidates: List of dicts, each containing:
                - name (str): Candidate name / filename
                - semantic_score (float): Cosine similarity %, 0-100
                - skill_match_rate (float): Skill match %, 0-100
                - experience_years (float): Years of experience

        Returns:
            Sorted list (best first) with added fields:
                - composite_score: Weighted final score
                - rank: Integer rank (1 = best)
                - score_breakdown: Dict of individual component scores
        """
        if not candidates:
            return []

        # Normalize experience years to 0-100 scale
        # Cap at 15 years = 100 (beyond that, diminishing returns)
        max_exp = 15.0
        for c in candidates:
            raw_exp = c.get("experience_years", 0)
            c["experience_score"] = min(100.0, (raw_exp / max_exp) * 100)

        # Compute composite score for each candidate
        for c in candidates:
            semantic = c.get("semantic_score", 0.0)
            skill = c.get("skill_match_rate", 0.0)
            experience = c.get("experience_score", 0.0)

            composite = (
                self.semantic_weight * semantic +
                self.skill_weight * skill +
                self.experience_weight * experience
            )

            c["composite_score"] = round(composite, 2)
            c["score_breakdown"] = {
                "semantic_similarity": round(semantic, 1),
                "skill_match": round(skill, 1),
                "experience": round(experience, 1),
            }

        # Sort by composite score descending
        ranked = sorted(candidates, key=lambda x: x["composite_score"], reverse=True)

        # Assign rank positions
        for i, candidate in enumerate(ranked):
            candidate["rank"] = i + 1

        return ranked

    def get_top_n(self, candidates: List[Dict], n: int = 3) -> List[Dict]:
        """Return only the top N candidates after ranking."""
        ranked = self.rank(candidates)
        return ranked[:n]

    def generate_ranking_summary(self, ranked_candidates: List[Dict]) -> str:
        """
        Generate a human-readable ranking summary for display.

        Args:
            ranked_candidates: Output from rank().

        Returns:
            Formatted multi-line string summary.
        """
        lines = ["=" * 50, "CANDIDATE RANKING RESULTS", "=" * 50]

        for c in ranked_candidates:
            lines.append(f"\nRank #{c['rank']}: {c['name']}")
            lines.append(f"  Composite Score : {c['composite_score']:.1f}%")
            lines.append(f"  Semantic Match  : {c['score_breakdown']['semantic_similarity']:.1f}%")
            lines.append(f"  Skill Match     : {c['score_breakdown']['skill_match']:.1f}%")
            lines.append(f"  Experience Score: {c['score_breakdown']['experience']:.1f}%")
            if c.get("missing_skills"):
                top_missing = c["missing_skills"][:3]
                lines.append(f"  Missing Skills  : {', '.join(top_missing)}")

        lines.append("\n" + "=" * 50)
        return "\n".join(lines)
