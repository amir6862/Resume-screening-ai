# 🎯 Resume Screening AI

> AI-powered resume analysis system using NLP, Sentence-BERT embeddings, and Streamlit.

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.35-red.svg)](https://streamlit.io)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 📋 Overview

Resume Screening AI automates candidate evaluation by combining semantic NLP with
rule-based skill analysis. Given a resume (PDF or TXT) and a job description, it outputs:

| Feature | Description |
|---|---|
| 🎯 Match Score | Semantic cosine similarity using Sentence-BERT |
| 🔍 Skill Gap Analysis | Missing vs matched skills using NER |
| 🏆 Candidate Ranking | Weighted composite scoring for multiple resumes |
| 💡 Improvement Tips | Actionable suggestions to improve the resume |

---

## 🏗️ Architecture

```
resume-screening-ai/
├── app/
│   ├── extractor.py        # PDF/TXT text extraction (PyMuPDF)
│   ├── preprocessor.py     # NLP cleaning pipeline (spaCy)
│   ├── embedder.py         # Sentence-BERT embeddings
│   ├── scorer.py           # Cosine similarity scoring
│   ├── skill_extractor.py  # NER + skill keyword matching
│   ├── ranker.py           # Multi-candidate ranking
│   ├── advisor.py          # Resume improvement suggestions
│   └── pipeline.py         # Main orchestration
├── data/
│   └── sample_resumes/     # Example resumes for testing
├── tests/
│   └── test_pipeline.py    # Unit tests
├── streamlit_app.py        # Streamlit UI
└── requirements.txt
```

---

## ⚙️ Tech Stack

| Component | Technology |
|---|---|
| Language | Python 3.10+ |
| NLP | spaCy (en_core_web_sm) |
| Embeddings | Sentence-Transformers (all-MiniLM-L6-v2) |
| Similarity | scikit-learn cosine_similarity |
| PDF Parsing | PyMuPDF (fitz) |
| UI | Streamlit + Plotly |

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/resume-screening-ai.git
cd resume-screening-ai
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

### 3. Run the Streamlit app
```bash
streamlit run streamlit_app.py
```

### 4. Run tests
```bash
python tests/test_pipeline.py
```

---

## 🎓 How the AI Works

### Step 1 — Text Extraction
PyMuPDF extracts text from PDF files page-by-page. For TXT files,
standard file reading is used with UTF-8 encoding.

### Step 2 — NLP Preprocessing
spaCy tokenizes and lemmatizes the text:
- "managing" → "manage", "developers" → "developer"
- Removes stopwords, URLs, emails, phone numbers
- Preserves semantically meaningful words

### Step 3 — Semantic Embeddings
Sentence-BERT (all-MiniLM-L6-v2) converts text to 384-dimensional vectors.
Two sentences with similar meaning produce vectors close together in space,
even if they use different words.

### Step 4 — Cosine Similarity Scoring
```
similarity = dot(resume_vector, jd_vector) / (|resume_vector| × |jd_vector|)
```
Ranges from 0 (no match) to 1 (identical meaning). Converted to percentage.

### Step 5 — Skill Gap Analysis
Keywords from a curated skills database (~100 skills across 7 categories)
are matched against both the resume and JD. Missing skills = JD skills not in resume.

### Step 6 — Weighted Ranking (Multi-Candidate)
```
composite_score = 0.60 × semantic_score
               + 0.25 × skill_match_rate
               + 0.15 × experience_score
```
Weights are configurable in `app/ranker.py`.

---

## 📊 Sample Output

```
=== CANDIDATE RANKING RESULTS ===

Rank #1: alice_chen.pdf
  Composite Score : 76.4%
  Semantic Match  : 78.5%
  Skill Match     : 82.0%
  Experience Score: 46.7%

Rank #2: bob_smith.pdf
  Composite Score : 41.2%
  Semantic Match  : 42.0%
  Skill Match     : 28.0%
  Experience Score: 33.3%
  Missing Skills  : pytorch, docker, kubernetes
```

---

## 🔧 Configuration

### Embedding Model
Edit `app/pipeline.py` to change the embedding quality:

```python
pipeline = ScreeningPipeline(embedding_model="fast")     # Default, ~80MB
pipeline = ScreeningPipeline(embedding_model="balanced") # Better, ~420MB
pipeline = ScreeningPipeline(embedding_model="quality")  # Multilingual
```

### Ranking Weights
Edit `app/ranker.py`:
```python
ranker = CandidateRanker(
    semantic_weight=0.60,    # Adjust based on role type
    skill_weight=0.25,
    experience_weight=0.15
)
```

---

## 🧪 Running Tests

```bash
# Run all unit tests
python tests/test_pipeline.py

# With pytest (more detailed output)
pip install pytest
pytest tests/ -v
```

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgments

- [Sentence-Transformers](https://www.sbert.net/) by UKPLab
- [spaCy](https://spacy.io/) by Explosion AI
- [Streamlit](https://streamlit.io/) for the UI framework
- [PyMuPDF](https://pymupdf.readthedocs.io/) for PDF processing
