"""
test_pipeline.py
----------------
Unit tests for the Resume Screening AI pipeline.

Run with:
    python tests/test_pipeline.py
    # or with pytest:
    pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.extractor import ResumeExtractor
from app.preprocessor import TextPreprocessor
from app.skill_extractor import SkillExtractor
from app.scorer import MatchScorer
from app.advisor import ResumeAdvisor
from app.ranker import CandidateRanker
import numpy as np


# ── Sample Data ───────────────────────────────────────────────────────────────

RESUME_1 = """
Alice Chen
Senior Python Developer | alice@email.com

EXPERIENCE
Lead ML Engineer — DataCorp (2020–2024)
- Developed NLP pipelines using spaCy and Hugging Face transformers
- Built deep learning models with PyTorch, improving accuracy by 35%
- Led team of 6 engineers, managed agile sprints
- Deployed models using Docker and Kubernetes on AWS

Software Engineer — StartupXYZ (2017–2020)
- Built RESTful APIs with Django and FastAPI
- Worked with PostgreSQL and Redis for data storage

EDUCATION
M.S. Computer Science — Stanford University, 2017

SKILLS
Python, PyTorch, TensorFlow, NLP, spaCy, Docker, Kubernetes, AWS,
PostgreSQL, Redis, FastAPI, Django, scikit-learn, pandas, numpy
"""

RESUME_2 = """
Bob Smith
Frontend Developer | bob@email.com

EXPERIENCE
React Developer — WebAgency (2019–2024)
- Built responsive web applications with React and TypeScript
- Designed UI components, worked with REST APIs
- Basic Python scripting for automation

EDUCATION
B.S. Information Technology — State University, 2019

SKILLS
React, JavaScript, TypeScript, HTML, CSS, Tailwind, Python (basic), REST APIs
"""

JOB_DESCRIPTION = """
Senior Machine Learning Engineer

We are seeking an experienced ML Engineer to join our AI team.

Requirements:
- 3+ years of Python development
- Strong experience with machine learning and NLP
- Proficiency in PyTorch or TensorFlow
- Experience with Docker and Kubernetes
- Cloud experience (AWS preferred)
- Strong communication and leadership skills
- Experience with scikit-learn, pandas, numpy

Nice to have:
- Knowledge of transformers and BERT models
- Experience with spaCy
- Agile/Scrum experience
"""


# ── Test Functions ────────────────────────────────────────────────────────────

def test_extractor():
    print("\n--- Test: ResumeExtractor ---")
    extractor = ResumeExtractor()

    text = extractor.extract_from_bytes(RESUME_1.encode(), "alice.txt")
    assert len(text) > 100, "Extracted text too short"
    assert "Alice Chen" in text or "alice" in text.lower()

    print(f"✅ Extracted {len(text)} characters from TXT")


def test_preprocessor():
    print("\n--- Test: TextPreprocessor ---")
    preprocessor = TextPreprocessor()

    cleaned = preprocessor.clean(RESUME_1)
    assert len(cleaned) > 0
    # URLs and emails should be removed
    assert "@" not in cleaned
    assert "http" not in cleaned

    word_count_before = len(RESUME_1.split())
    word_count_after = len(cleaned.split())
    reduction = (1 - word_count_after / word_count_before) * 100

    print(f"✅ Preprocessed: {word_count_before} -> {word_count_after} words ({reduction:.0f}% reduction)")


def test_skill_extractor():
    print("\n--- Test: SkillExtractor ---")
    extractor = SkillExtractor()

    skills_1 = extractor.extract_all_skills_flat(RESUME_1)
    skills_2 = extractor.extract_all_skills_flat(RESUME_2)
    jd_skills = extractor.extract_all_skills_flat(JOB_DESCRIPTION)

    assert "python" in skills_1 or "Python" in skills_1
    assert len(skills_1) > len(skills_2)  # Alice has more relevant skills

    gap = extractor.compute_skill_gap(skills_1, jd_skills)
    assert "matched_skills" in gap
    assert "missing_skills" in gap
    assert 0 <= gap["skill_match_rate"] <= 100

    print(f"✅ Alice's skills: {len(skills_1)}, Bob's skills: {len(skills_2)}")
    print(f"✅ Alice's skill match rate: {gap['skill_match_rate']}%")
    print(f"✅ Missing skills: {gap['missing_skills'][:3]}")


def test_scorer():
    print("\n--- Test: MatchScorer ---")
    from app.embedder import ResumeEmbedder
    from app.preprocessor import TextPreprocessor

    preprocessor = TextPreprocessor()
    embedder = ResumeEmbedder(model_name="fast")
    scorer = MatchScorer()

    clean_1 = preprocessor.clean(RESUME_1)
    clean_2 = preprocessor.clean(RESUME_2)
    clean_jd = preprocessor.clean(JOB_DESCRIPTION)

    emb_1 = embedder.embed(clean_1)
    emb_2 = embedder.embed(clean_2)
    emb_jd = embedder.embed(clean_jd)

    score_1 = scorer.score(emb_1, emb_jd)
    score_2 = scorer.score(emb_2, emb_jd)

    assert 0 <= score_1 <= 100
    assert 0 <= score_2 <= 100
    assert score_1 > score_2, "Alice (ML engineer) should score higher than Bob (frontend dev)"

    print(f"✅ Alice (ML Engineer) score: {score_1:.1f}%")
    print(f"✅ Bob (Frontend Dev) score:  {score_2:.1f}%")
    print(f"✅ Alice correctly scores higher: {score_1 > score_2}")


def test_advisor():
    print("\n--- Test: ResumeAdvisor ---")
    advisor = ResumeAdvisor()
    extractor = SkillExtractor()

    jd_skills = extractor.extract_all_skills_flat(JOB_DESCRIPTION)
    resume_skills = extractor.extract_all_skills_flat(RESUME_2)  # Bob has gaps
    skill_gap = extractor.compute_skill_gap(resume_skills, jd_skills)

    suggestions = advisor.generate_suggestions(
        RESUME_2, 40.0, skill_gap, experience_years=5.0
    )

    assert len(suggestions) > 0
    priorities = [s["priority"] for s in suggestions]
    # Should have at least one HIGH priority suggestion for Bob (low score)
    assert "HIGH" in priorities

    print(f"✅ Generated {len(suggestions)} suggestions")
    print(f"✅ Priorities: {set(priorities)}")


def test_ranker():
    print("\n--- Test: CandidateRanker ---")
    ranker = CandidateRanker()

    candidates = [
        {
            "name": "alice.pdf",
            "semantic_score": 78.5,
            "skill_match_rate": 82.0,
            "experience_years": 7.0,
            "missing_skills": ["go", "kafka"]
        },
        {
            "name": "bob.pdf",
            "semantic_score": 42.0,
            "skill_match_rate": 28.0,
            "experience_years": 5.0,
            "missing_skills": ["python", "pytorch", "docker", "kubernetes"]
        }
    ]

    ranked = ranker.rank(candidates)

    assert ranked[0]["name"] == "alice.pdf", "Alice should be ranked #1"
    assert ranked[0]["rank"] == 1
    assert ranked[1]["rank"] == 2
    assert "composite_score" in ranked[0]

    print(f"✅ Rank #1: {ranked[0]['name']} ({ranked[0]['composite_score']:.1f}%)")
    print(f"✅ Rank #2: {ranked[1]['name']} ({ranked[1]['composite_score']:.1f}%)")


def run_all_tests():
    print("=" * 55)
    print("  RESUME SCREENING AI — TEST SUITE")
    print("=" * 55)

    tests = [
        ("Extractor", test_extractor),
        ("Preprocessor", test_preprocessor),
        ("Skill Extractor", test_skill_extractor),
        ("Scorer + Embedder", test_scorer),
        ("Advisor", test_advisor),
        ("Ranker", test_ranker),
    ]

    passed = 0
    failed = 0

    for name, test_fn in tests:
        try:
            test_fn()
            passed += 1
        except AssertionError as e:
            print(f"❌ FAILED: {name} — {e}")
            failed += 1
        except Exception as e:
            print(f"❌ ERROR in {name}: {type(e).__name__}: {e}")
            failed += 1

    print("\n" + "=" * 55)
    print(f"  Results: {passed} passed, {failed} failed")
    print("=" * 55)

    if failed == 0:
        print("\n🎉 All tests passed! Your pipeline is working correctly.")
    else:
        print("\n⚠️  Some tests failed. Check the errors above.")


if __name__ == "__main__":
    run_all_tests()
